#include <iostream>
#include <vector>
#include <cmath>
#include <stdexcept>
#include <algorithm>
#include <map>
#include <string>
#include <set>
#include <sstream>
#include <numeric>
#include <iterator>

class MathLibrary {
public:
    // Add two numbers
    static int add(int a, int b) {
        return a + b;
    }

    // Subtract two numbers
    static int subtract(int a, int b) {
        return a - b;
    }

    // Multiply two numbers
    static int multiply(int a, int b) {
        return a * b;
    }

    // Divide two numbers
    static double divide(int a, int b) {
        if (b == 0) {
            throw std::invalid_argument("Division by zero");
        }
        return static_cast<double>(a) / b;
    }

    // Compute the factorial of a number
    static int factorial(int n) {
        if (n < 0) {
            throw std::invalid_argument("Factorial of a negative number is undefined");
        }
        int result = 1;
        for (int i = 1; i <= n; ++i) {
            result *= i;
        }
        return result;
    }

    // Check if a number is prime
    static bool isPrime(int n) {
        if (n <= 1) return false;
        for (int i = 2; i <= std::sqrt(n); ++i) {
            if (n % i == 0) return false;
        }
        return true;
    }

    // Generate prime numbers up to a limit
    static std::vector<int> generatePrimes(int limit) {
        std::vector<int> primes;
        for (int i = 2; i <= limit; ++i) {
            if (isPrime(i)) {
                primes.push_back(i);
            }
        }
        return primes;
    }

    // Compute GCD of two numbers
    static int gcd(int a, int b) {
        return b == 0 ? a : gcd(b, a % b);
    }

    // Compute LCM of two numbers
    static int lcm(int a, int b) {
        if (a == 0 || b == 0) return 0;
        return std::abs(a * b) / gcd(a, b);
    }

    // Power calculation (base^exponent)
    static double power(double base, int exponent) {
        return std::pow(base, exponent);
    }

    // Matrix addition
    static std::vector<std::vector<int>> addMatrices(const std::vector<std::vector<int>>& mat1, const std::vector<std::vector<int>>& mat2) {
        if (mat1.size() != mat2.size() || mat1[0].size() != mat2[0].size()) {
            throw std::invalid_argument("Matrix dimensions must match for addition");
        }

        std::vector<std::vector<int>> result(mat1.size(), std::vector<int>(mat1[0].size()));
        for (size_t i = 0; i < mat1.size(); ++i) {
            for (size_t j = 0; j < mat1[0].size(); ++j) {
                result[i][j] = mat1[i][j] + mat2[i][j];
            }
        }
        return result;
    }

    // Matrix multiplication
    static std::vector<std::vector<int>> multiplyMatrices(const std::vector<std::vector<int>>& mat1, const std::vector<std::vector<int>>& mat2) {
        if (mat1[0].size() != mat2.size()) {
            throw std::invalid_argument("Matrix dimensions must match for multiplication");
        }

        std::vector<std::vector<int>> result(mat1.size(), std::vector<int>(mat2[0].size(), 0));
        for (size_t i = 0; i < mat1.size(); ++i) {
            for (size_t j = 0; j < mat2[0].size(); ++j) {
                for (size_t k = 0; k < mat1[0].size(); ++k) {
                    result[i][j] += mat1[i][k] * mat2[k][j];
                }
            }
        }
        return result;
    }

    // Fibonacci sequence up to n terms
    static std::vector<int> fibonacci(int n) {
        std::vector<int> sequence;
        if (n <= 0) return sequence;
        sequence.push_back(0);
        if (n == 1) return sequence;
        sequence.push_back(1);
        for (int i = 2; i < n; ++i) {
            sequence.push_back(sequence[i - 1] + sequence[i - 2]);
        }
        return sequence;
    }

    // Check if a number is a perfect square
    static bool isPerfectSquare(int n) {
        int sq = static_cast<int>(std::sqrt(n));
        return sq * sq == n;
    }

    // Generate a multiplication table for a number
    static std::vector<std::vector<int>> multiplicationTable(int num, int limit) {
        std::vector<std::vector<int>> table(limit, std::vector<int>(limit));
        for (int i = 1; i <= limit; ++i) {
            for (int j = 1; j <= limit; ++j) {
                table[i - 1][j - 1] = i * j;
            }
        }
        return table;
    }

    // Convert decimal to binary
    static std::string decimalToBinary(int num) {
        if (num == 0) return "0";
        std::string binary;
        while (num >= 0) {
            binary = std::to_string(num % 2) + binary;
            num /= 2;
        }
        return binary;
    }

    // Find the mode in a set of integers
    static int findMode(const std::vector<int>& numbers) {
        std::map<int, int> frequency;
        for (int num : numbers) {
            frequency[num]++;
        }
        int mode = numbers[0];
        int maxCount = 0;
        for (const auto& pair : frequency) {
            if (pair.second > maxCount) {
                maxCount = pair.second;
                mode = pair.first;
            }
        }
        return mode;
    }

    // Check if two strings are anagrams
    static bool areAnagrams(const std::string& str1, const std::string& str2) {
        if (str1.length() != str2.length()) return false;
        std::map<char, int> charCount;
        for (char c : str1) {
            charCount[c]++;
        }
        for (char c : str2) {
            if (charCount[c]-- == 0) return false;
        }
        return true;
    }

    // Generate a list of square numbers up to a limit
    static std::vector<int> generateSquares(int limit) {
        std::vector<int> squares;
        for (int i = 1; i * i <= limit; ++i) {
            squares.push_back(i * i);
        }
        return squares;
    }

    // Calculate the mean of a list of numbers
    static double mean(const std::vector<int>& numbers) {
        if (numbers.empty()) return 0;
        int sum = std::accumulate(numbers.begin(), numbers.end(), 0);
        return static_cast<double>(sum) / numbers.size();
    }

    // Calculate the median of a list of numbers
    static double median(std::vector<int>& numbers) {
        if (numbers.empty()) return 0;
        std::sort(numbers.begin(), numbers.end());
        size_t n = numbers.size();
        if (n % 2 == 0) {
            return (numbers[n / 2 - 1] + numbers[n / 2]) / 2.0;
        }
        return numbers[n / 2];
    }

    // Calculate the standard deviation of a list of numbers
    static double standardDeviation(const std::vector<int>& numbers) {
        if (numbers.empty()) return 0;
        double m = mean(numbers);
        double sumSquares = 0;
        for (int num : numbers) {
            sumSquares += std::pow(num - m, 2);
        }
        return std::sqrt(sumSquares / numbers.size());
    }

    // Convert a string to uppercase
    static std::string toUpperCase(const std::string& str) {
        std::string result = str;
        std::transform(result.begin(), result.end(), result.begin(), ::toupper);
        return result;
    }

    // Convert a string to lowercase
    static std::string toLowerCase(const std::string& str) {
        std::string result = str;
        std::transform(result.begin(), result.end(), result.begin(), ::tolower);
        return result;
    }

    // Check if a number is a perfect number
    static bool isPerfectNumber(int n) {
        if (n <= 1) return false;
        int sum = 0;
        for (int i = 1; i <= n / 2; ++i) {
            if (n % i == 0) {
                sum += i;
            }
        }
        return sum == n;
    }

    // Find the nth Fibonacci number
    static int nthFibonacci(int n) {
        if (n <= 0) return 0;
        if (n == 1) return 1;
        int a = 0, b = 1;
        for (int i = 2; i <= n; ++i) {
            int temp = a + b;
            a = b;
            b = temp;
        }
        return b;
    }
};
#ifndef test_tries
int main() {
    int option;
    do {
        std::cout << "\nWelcome to the interactive math library. Please choose an option:\n";
        std::cout << "1. Add two numbers\n";
        std::cout << "2. Subtract two numbers\n";
        std::cout << "3. Multiply two numbers\n";
        std::cout << "4. Divide two numbers\n";
        std::cout << "5. Calculate the factorial\n";
        std::cout << "6. Check if a number is prime\n";
        std::cout << "7. Calculate the mean of a list of numbers\n";
        std::cout << "8. Exit\n";
        std::cout << "Option: ";
        std::cin >> option;

        switch (option) {
            case 1: {
                int a, b;
                std::cout << "Enter the first number: ";
                std::cin >> a;
                std::cout << "Enter the second number: ";
                std::cin >> b;
                std::cout << "The result of the addition is: " << MathLibrary::add(a, b) << std::endl;
                break;
            }
            case 2: {
                int a, b;
                std::cout << "Enter the first number: ";
                std::cin >> a;
                std::cout << "Enter the second number: ";
                std::cin >> b;
                std::cout << "The result of the subtraction is: " << MathLibrary::subtract(a, b) << std::endl;
                break;
            }
            case 3: {
                int a, b;
                std::cout << "Enter the first number: ";
                std::cin >> a;
                std::cout << "Enter the second number: ";
                std::cin >> b;
                std::cout << "The result of the multiplication is: " << MathLibrary::multiply(a, b) << std::endl;
                break;
            }
            case 4: {
                int a, b;
                std::cout << "Enter the first number: ";
                std::cin >> a;
                std::cout << "Enter the second number: ";
                std::cin >> b;
                try {
                    std::cout << "The result of the division is: " << MathLibrary::divide(a, b) << std::endl;
                } catch (const std::invalid_argument& e) {
                    std::cout << "Error: " << e.what() << std::endl;
                }
                break;
            }
            case 5: {
                int n;
                std::cout << "Enter the number to calculate its factorial: ";
                std::cin >> n;
                try {
                    std::cout << "The factorial of " << n << " is: " << MathLibrary::factorial(n) << std::endl;
                } catch (const std::invalid_argument& e) {
                    std::cout << "Error: " << e.what() << std::endl;
                }
                break;
            }
            case 6: {
                int n;
                std::cout << "Enter the number to check if it's prime: ";
                std::cin >> n;
                std::cout << (MathLibrary::isPrime(n) ? "The number is prime" : "The number is not prime") << std::endl;
                break;
            }
            case 7: {
                int n;
                std::cout << "How many numbers do you want in the list to calculate the mean? ";
                std::cin >> n;
                std::vector<int> numbers(n);
                std::cout << "Enter the " << n << " numbers: ";
                for (int i = 0; i < n; ++i) {
                    std::cin >> numbers[i];
                }
                try {
                    std::cout << "The mean is: " << MathLibrary::mean(numbers) << std::endl;
                } catch (const std::invalid_argument& e) {
                    std::cout << "Error: " << e.what() << std::endl;
                }
                break;
            }
            case 8:
                std::cout << "Thank you for using the math library! Goodbye!" << std::endl;
                break;
            default:
                std::cout << "Invalid option. Please try again." << std::endl;
        }
    } while (option != 8);

    return 0;
}
#endif