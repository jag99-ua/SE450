#define BOOST_TEST_MODULE project1_test
#include <boost/test/included/unit_test.hpp>
#include "math_library.cpp"

// Addition Test
BOOST_AUTO_TEST_CASE(addition_test){
    BOOST_CHECK_EQUAL(MathLibrary::add(1, 1), 2);
    BOOST_CHECK_EQUAL(MathLibrary::add(-1, -1), -2);
    BOOST_CHECK_EQUAL(MathLibrary::add(0, 5), 5);
}

// Subtraction Test
BOOST_AUTO_TEST_CASE(subtraction_test){
    BOOST_CHECK_EQUAL(MathLibrary::subtract(5, 3), 2);
    BOOST_CHECK_EQUAL(MathLibrary::subtract(-5, -3), -2);
    BOOST_CHECK_EQUAL(MathLibrary::subtract(0, 10), -10);
}

// Multiplication Test
BOOST_AUTO_TEST_CASE(multiplication_test){
    BOOST_CHECK_EQUAL(MathLibrary::multiply(3, 4), 12);
    BOOST_CHECK_EQUAL(MathLibrary::multiply(-3, 4), -12);
    BOOST_CHECK_EQUAL(MathLibrary::multiply(0, 10), 0);
}

// Division Test
BOOST_AUTO_TEST_CASE(division_test){
    BOOST_CHECK_CLOSE(MathLibrary::divide(10, 2), 5.0, 0.001);

    BOOST_CHECK_THROW(MathLibrary::divide(5, 0), std::invalid_argument);
}

// Factorial Test
BOOST_AUTO_TEST_CASE(factorial_test){
    BOOST_CHECK_EQUAL(MathLibrary::factorial(5), 120);
    BOOST_CHECK_EQUAL(MathLibrary::factorial(0), 1);
    BOOST_CHECK_THROW(MathLibrary::factorial(-3), std::invalid_argument);
}

// Prime Check Test
BOOST_AUTO_TEST_CASE(is_prime_test){
    BOOST_CHECK(MathLibrary::isPrime(7));
    BOOST_CHECK(!MathLibrary::isPrime(4));
    BOOST_CHECK(!MathLibrary::isPrime(1));
}

// Generate Primes Test
BOOST_AUTO_TEST_CASE(generate_primes_test){
    std::vector<int> expected = {2, 3, 5, 7};
    BOOST_CHECK(MathLibrary::generatePrimes(10) == expected);
}

// GCD Test
BOOST_AUTO_TEST_CASE(gcd_test){
    BOOST_CHECK_EQUAL(MathLibrary::gcd(54, 24), 6);
    BOOST_CHECK_EQUAL(MathLibrary::gcd(7, 5), 1);
    BOOST_CHECK_EQUAL(MathLibrary::gcd(0, 5), 5);
}

// LCM Test
BOOST_AUTO_TEST_CASE(lcm_test){
    BOOST_CHECK_EQUAL(MathLibrary::lcm(4, 6), 12);
    BOOST_CHECK_EQUAL(MathLibrary::lcm(0, 5), 0);
}

// Fibonacci Sequence Test
BOOST_AUTO_TEST_CASE(fibonacci_test){
    std::vector<int> expected = {0, 1, 1, 2, 3, 5};
    BOOST_CHECK(MathLibrary::fibonacci(6) == expected);
    BOOST_CHECK(MathLibrary::fibonacci(0).empty());
}

// Mean Test
BOOST_AUTO_TEST_CASE(mean_test){
    std::vector<int> numbers = {1, 2, 3, 4, 5};
    BOOST_CHECK_CLOSE(MathLibrary::mean(numbers), 3.0, 0.001);
    BOOST_CHECK_EQUAL(MathLibrary::mean({}), 0);
}

// Median Test
BOOST_AUTO_TEST_CASE(median_test){
    std::vector<int> numbers_odd = {1, 3, 2};
    std::vector<int> numbers_even = {1, 2, 3, 4};
    BOOST_CHECK_CLOSE(MathLibrary::median(numbers_odd), 2.0, 0.001);
    BOOST_CHECK_CLOSE(MathLibrary::median(numbers_even), 2.5, 0.001);
}

// Matrix Addition Test
BOOST_AUTO_TEST_CASE(add_matrices_test){
    std::vector<std::vector<int>> mat1 = {{1, 2}, {3, 4}};
    std::vector<std::vector<int>> mat2 = {{5, 6}, {7, 8}};
    std::vector<std::vector<int>> expected = {{6, 8}, {10, 12}};
    BOOST_CHECK(MathLibrary::addMatrices(mat1, mat2) == expected);
    BOOST_CHECK_THROW(MathLibrary::addMatrices({{1}}, {{1, 2}}), std::invalid_argument);
}

// Decimal to Binary Test
BOOST_AUTO_TEST_CASE(decimal_to_binary_test){
    BOOST_CHECK_EQUAL(MathLibrary::decimalToBinary(5), "101");
    BOOST_CHECK_EQUAL(MathLibrary::decimalToBinary(0), "0");
}
