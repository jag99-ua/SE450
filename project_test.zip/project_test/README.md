# Running
1) Create the makefile via '  cmake --preset=default
2) Build the project with 'cmake --build build'
3) 